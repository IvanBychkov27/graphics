//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Example.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_EXAMPLTYPE                  129
#define IDD_DIALOG_SCALE                130
#define IDD_DIALOG_LOOK                 131
#define IDC_EDIT_SCALE_X                1000
#define IDC_EDIT_SCALE_Y                1001
#define IDC_EDIT_ANGLE                  1002
#define IDC_EDIT_EYES_X                 1003
#define IDC_EDIT_EYES_Y                 1004
#define IDC_EDIT_EYES_Z                 1005
#define IDC_EDIT_POINT_X                1006
#define IDC_EDIT_POINT_Y                1007
#define IDC_EDIT_POINT_Z                1008
#define IDC_EDIT_VECTOR_X               1009
#define IDC_EDIT_VECTOR_Y               1010
#define IDC_EDIT_VECTOR_Z               1011
#define ID_VIEW_SCALE                   32771
#define ID_VIEW_DEPTH                   32776
#define ID_VIEW_MODE                    32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
